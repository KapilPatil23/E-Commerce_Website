1) Developed and implemented a full-stack e-commerce website using the
 MERN (MongoDB, Express, React, Node.js) stack.
2) Designed and integrated user-friendly interfaces with React components.
3) Implemented secure authentication and payment processing.
4) Managed and optimized the MongoDB database for efficient data storage
and retrieval.
